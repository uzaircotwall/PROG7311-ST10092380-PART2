﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace prog2.Models
{
    public partial class Farmer
    {
        public Farmer()
        {
            ProductsNavigation = new HashSet<Product>();
            Products = new HashSet<Product>();
        }

        [Key]
        public int FarmerId { get; set; }
        [StringLength(255)]
        [Unicode(false)]
        public string Name { get; set; } = null!;
        [StringLength(255)]
        [Unicode(false)]
        public string Address { get; set; } = null!;

        [InverseProperty("Farmer")]
        public virtual ICollection<Product> ProductsNavigation { get; set; }

        [ForeignKey("FarmerId")]
        [InverseProperty("Farmers")]
        public virtual ICollection<Product> Products { get; set; }
    }
}
