﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace prog2.Models
{
    public partial class ApplicationDbContext2 : DbContext
    {
        public ApplicationDbContext2()
        {
        }

        public ApplicationDbContext2(DbContextOptions<ApplicationDbContext2> options)
            : base(options)
        {
        }
        public virtual DbSet<Employee> Employees { get; set; } = null!;
        public virtual DbSet<Farmer> Farmers { get; set; } = null!;
        public virtual DbSet<Product> Products { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=(localdb)\\mssqllocaldb;Database=aspnet-prog2-53bc9b9d-9d6a-45d4-8429-2a2761773502;Trusted_Connection=True;MultipleActiveResultSets=true");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
           

            modelBuilder.Entity<Employee>(entity =>
            {
                entity.Property(e => e.EmployeeId).ValueGeneratedNever();
            });

            modelBuilder.Entity<Farmer>(entity =>
            {
                entity.Property(e => e.FarmerId).ValueGeneratedNever();

                entity.HasMany(d => d.Products)
                    .WithMany(p => p.Farmers)
                    .UsingEntity<Dictionary<string, object>>(
                        "FarmerProduct",
                        l => l.HasOne<Product>().WithMany().HasForeignKey("ProductId").OnDelete(DeleteBehavior.ClientSetNull).HasConstraintName("FK__FarmerPro__Produ__6477ECF3"),
                        r => r.HasOne<Farmer>().WithMany().HasForeignKey("FarmerId").OnDelete(DeleteBehavior.ClientSetNull).HasConstraintName("FK__FarmerPro__Farme__6383C8BA"),
                        j =>
                        {
                            j.HasKey("FarmerId", "ProductId").HasName("PK__FarmerPr__B85B44E42ED5E363");

                            j.ToTable("FarmerProducts");
                        });
            });

            modelBuilder.Entity<Product>(entity =>
            {
                entity.Property(e => e.ProductId).ValueGeneratedNever();

                entity.HasOne(d => d.Farmer)
                    .WithMany(p => p.ProductsNavigation)
                    .HasForeignKey(d => d.FarmerId)
                    .HasConstraintName("FK__Products__Farmer__5EBF139D");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
