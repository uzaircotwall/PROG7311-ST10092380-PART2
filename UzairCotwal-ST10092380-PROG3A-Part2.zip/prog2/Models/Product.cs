﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace prog2.Models
{
    public partial class Product
    {
        public Product()
        {
            Farmers = new HashSet<Farmer>();
        }

        [Key]
        public int ProductId { get; set; }
        [StringLength(255)]
        [Unicode(false)]
        public string Name { get; set; } = null!;
        [Column(TypeName = "decimal(10, 2)")]
        public decimal Price { get; set; }
        [Column(TypeName = "date")]
        public DateTime DateSupplied { get; set; }
        public int? FarmerId { get; set; }

        [ForeignKey("FarmerId")]
        [InverseProperty("ProductsNavigation")]
        public virtual Farmer? Farmer { get; set; }

        [ForeignKey("ProductId")]
        [InverseProperty("Products")]
        public virtual ICollection<Farmer> Farmers { get; set; }
    }
}
